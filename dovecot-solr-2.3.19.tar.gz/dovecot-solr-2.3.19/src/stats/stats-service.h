#ifndef STATS_SERVICE_H
#define STATS_SERVICE_H

void stats_services_init(void);
void stats_services_deinit(void);

#endif
