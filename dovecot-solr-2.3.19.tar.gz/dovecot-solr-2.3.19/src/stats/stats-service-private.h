#ifndef STATS_SERVICE_PRIVATE_H
#define STATS_SERVICE_PRIVATE_H

#include "stats-service.h"

void stats_service_openmetrics_init(void);

#endif
