#!/bin/sh

cat > $1
exit 0;
