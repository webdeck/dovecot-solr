#!/bin/sh

cat > /dev/null
exit 1;
