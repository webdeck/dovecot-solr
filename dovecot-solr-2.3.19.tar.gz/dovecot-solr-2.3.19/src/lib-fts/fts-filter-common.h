#ifndef FTS_FILTER_COMMON_H
#define FTS_FILTER_COMMON_H

void fts_filter_truncate_token(string_t *token, size_t max_length);

#endif
